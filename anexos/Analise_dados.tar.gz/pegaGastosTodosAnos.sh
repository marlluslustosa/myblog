#!/bin/bash
#script pra pegar lista com todas as refeicoes de todo o parlamento

quantPaginas=`(python GetJarbas.py 1 | egrep class=\"end\"\>  |  cut -d'>' -f2 | cut -d'<' -f1)`

rm -rf listaGasto.txt

for ((x=1;x<=$quantPaginas;x++))
do
    #aqui era a linha que dava certo em 2017
	#python GetJarbas.py $x | grep field-value|  awk -F "<td "  '{print $7}' | awk -F ">" '{print $2,$4}' | sed "s/<\/td/ /" | sed "s/R$\ //" >> listaGasto.txt
	
	#atualização do código para 2018
	python GetJarbas.py $x | grep documentId | awk -F "<td "  '{print $2,$5,$9}' | sed -e 's/class=\"field\-jarbas\"><a\ href="\/layers\/#\// /g' | awk -F "\">"  '{print $1,$4,$5}' >> listaGasto.txt
done

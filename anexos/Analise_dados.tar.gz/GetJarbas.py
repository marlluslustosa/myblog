import requests
import sys

numPagina = sys.argv[1]
response = requests.get("https://jarbas.serenatadeamor.org/dashboard/chamber_of_deputies/reimbursement/?&subquota_id=13&p={0}".format(numPagina))

print response.content

